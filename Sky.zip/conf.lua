function love.conf(t)
    t.window.title = 'Celeste Chafa'
    t.window.width = 866
    t.window.height = 411
    t.window.resizable = true
    t.window.minwidth = 866
    t.window.minheight = 411
    t.window.vsync = 1
    --t.window.fullscreen = true
end
